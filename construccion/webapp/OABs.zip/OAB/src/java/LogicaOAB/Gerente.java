
package LogicaOAB;

import java.io.Serializable;



/**
 * 
 */
public class Gerente extends Usuario implements Serializable {

    /**
     * Default constructor
     */
    public Gerente() {
    }



}