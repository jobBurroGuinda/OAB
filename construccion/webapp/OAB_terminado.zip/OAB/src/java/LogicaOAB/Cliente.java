
package LogicaOAB;

import java.io.Serializable;

/**
 * 
 */
public class Cliente extends Persona implements Serializable {

    
    /**
     * Default constructor
     */
    public Cliente() {
    }

    
    
    

    /**
     * @return
     */
    public boolean altaCliente() {
        // TODO implement here
        return false;
    }

    

    /**
     * @return
     */
    public boolean editarCliente() {
        // TODO implement here
        return false;
    }

    /**
     * @return
     */
    public boolean bajaCliente() {
        // TODO implement here
        return false;
    }

}