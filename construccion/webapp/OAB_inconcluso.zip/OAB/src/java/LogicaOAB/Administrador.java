
package LogicaOAB;

import java.io.Serializable;



/**
 * 
 */
public class Administrador extends Usuario implements Serializable {

    /**
     * Default constructor
     */
    public Administrador() {
    }

    


}