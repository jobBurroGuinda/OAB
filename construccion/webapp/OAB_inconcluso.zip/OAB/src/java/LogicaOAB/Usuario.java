
package LogicaOAB;

import java.io.Serializable;
import java.util.ArrayList;


/**
 * 
 */
public class Usuario extends Persona implements Serializable {


    /**
     * 
     */
    private int idUsuario;

    /**
     * 
     */
    private String nomUsuario;

    /**
     * 
     */
    private String password;

    /**
     * 
     */
    private int idPrivilegio;
    
    
    private String privilegio;

    
    /**
     * Default constructor
     */
    public Usuario() {
    }

    public Usuario(int idUsuario, String nomUsuario, String password, int idPrivilegio, int idPersona, String nombre, String apellidoPaterno, String apellidoMaterno, long telefono, String emal, String facebook) {
        super(idPersona, nombre, apellidoPaterno, apellidoMaterno, telefono, emal, facebook);
        this.idUsuario = idUsuario;
        this.nomUsuario = nomUsuario;
        this.password = password;
        this.idPrivilegio = idPrivilegio;
    }

    public Usuario(int idUsuario, String nomUsuario, String password, int idPrivilegio, String nombre, String apellidoPaterno, String apellidoMaterno, long telefono, String emal, String facebook) {
        super(nombre, apellidoPaterno, apellidoMaterno, telefono, emal, facebook);
        this.idUsuario = idUsuario;
        this.nomUsuario = nomUsuario;
        this.password = password;
        this.idPrivilegio = idPrivilegio;
    }

    public Usuario(int idUsuario, String nomUsuario, String password, int idPrivilegio) {
        this.idUsuario = idUsuario;
        this.nomUsuario = nomUsuario;
        this.password = password;
        this.idPrivilegio = idPrivilegio;
    }

    public Usuario(String nomUsuario, String password, int idPrivilegio, int idPersona, String nombre, String apellidoPaterno, String apellidoMaterno, long telefono, String emal, String facebook) {
        super(idPersona, nombre, apellidoPaterno, apellidoMaterno, telefono, emal, facebook);
        this.nomUsuario = nomUsuario;
        this.password = password;
        this.idPrivilegio = idPrivilegio;
    }

    public Usuario(String nomUsuario, String password, int idPrivilegio, String nombre, String apellidoPaterno, String apellidoMaterno, long telefono, String emal, String facebook) {
        super(nombre, apellidoPaterno, apellidoMaterno, telefono, emal, facebook);
        this.nomUsuario = nomUsuario;
        this.password = password;
        this.idPrivilegio = idPrivilegio;
    }

    public Usuario(int idPersona, String nombre) {
        super(idPersona, nombre);
    }
    
    
    
    
    /**
     * @return
     */
    public boolean altaUsuario() {
        // TODO implement here
        return false;
    }

    /**
     * @return
     */
    public ArrayList<Usuario> verUsuario() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public boolean editarUsuario() {
        // TODO implement here
        return false;
    }

    /**
     * @return
     */
    public boolean bajaUsuario() {
        // TODO implement here
        return false;
    }

    /**
     * @return the idUsuario
     */
    public int getIdUsuario() {
        return idUsuario;
    }

    /**
     * @param idUsuario the idUsuario to set
     */
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    /**
     * @return the nomUsuario
     */
    public String getNomUsuario() {
        return nomUsuario;
    }

    /**
     * @param nomUsuario the nomUsuario to set
     */
    public void setNomUsuario(String nomUsuario) {
        this.nomUsuario = nomUsuario;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the idPrivilegio
     */
    public int getIdPrivilegio() {
        return idPrivilegio;
    }

    /**
     * @param idPrivilegio the idPrivilegio to set
     */
    public void setIdPrivilegio(int idPrivilegio) {
        this.idPrivilegio = idPrivilegio;
    }

    /**
     * @return the privilegio
     */
    public String getPrivilegio() {
        return privilegio;
    }

    /**
     * @param privilegio the privilegio to set
     */
    public void setPrivilegio(String privilegio) {
        this.privilegio = privilegio;
    }


}