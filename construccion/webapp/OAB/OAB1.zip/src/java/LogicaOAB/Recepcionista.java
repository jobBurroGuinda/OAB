
package LogicaOAB;

import java.io.Serializable;



/**
 * 
 */
public class Recepcionista extends Usuario implements Serializable {

    /**
     * Default constructor
     */
    public Recepcionista() {
    }



}